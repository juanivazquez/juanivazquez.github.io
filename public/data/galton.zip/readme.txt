7/24/2017 -- Jeremy Freese [jfreese@stanford.edu]

galton.dta

These are the data famously used by Galton on the relationship between the 
heights of parents and those of their children.  The heights are in inches.

The variable family is a family ID variable, as the data include multiple
children per family.

The data were upload to familiarize JF with how the repository works, but
the data are legit and available (public domain) to be used in teaching or any other
purpose. 

